import E404 from './404.js';
export default E404;
//# sourceMappingURL=index.js.map