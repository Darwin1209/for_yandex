import Profile from './Profile.js';
export default Profile;
//# sourceMappingURL=index.js.map