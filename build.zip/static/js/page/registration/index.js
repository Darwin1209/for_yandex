import Registration from './Registration.js';
export default Registration;
//# sourceMappingURL=index.js.map