import ProfileChangeData from './Profile.js';
export default ProfileChangeData;
//# sourceMappingURL=index.js.map