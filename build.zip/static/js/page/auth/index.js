import Auth from './Auth.js';
export default Auth;
//# sourceMappingURL=index.js.map