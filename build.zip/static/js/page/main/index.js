import Main from './Main.js';
export default Main;
//# sourceMappingURL=index.js.map