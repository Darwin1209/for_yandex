export const listText = [
    {
        name: 'Сергей',
        message: 'Изображение',
        date: '10:32',
        count: 1,
    },
    {
        name: 'Илья',
        message: 'Друзья, выпуск новостей!',
        date: '10:32',
        count: 1,
    },
    {
        name: 'Игорян',
        message: 'И Human Design рекомендуют',
        date: '10:32',
        count: 1,
    },
    {
        name: 'Игорян',
        message: 'Какой-то текст?',
        date: '10:32',
        count: 1,
    },
    {
        name: 'Игорян',
        message: 'Какой-то текст?',
        date: '10:32',
        count: 1,
    },
    {
        name: 'Игорян',
        message: 'Какой-то текст?',
        date: '10:32',
        count: 1,
    },
    {
        name: 'Игорян',
        message: 'Какой-то текст?',
        date: '10:32',
        count: 1,
    },
    {
        name: 'Игорян',
        message: 'Какой-то текст?',
        date: '10:32',
        count: 1,
    },
];
//# sourceMappingURL=mock.js.map