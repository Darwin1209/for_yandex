import ProfileChangePass from './Profile.js';
export default ProfileChangePass;
//# sourceMappingURL=index.js.map