import Error from './Error.js';
export default Error;
//# sourceMappingURL=index.js.map