import ProfileComp from './ProfileComp.js';
export default ProfileComp;
//# sourceMappingURL=index.js.map