# Проект "Чат"

## Макет

За основу взят макет из яндекса, но с некоторыми мелкими доработками.
https://www.figma.com/file/24EUnEHGEDNLdOcxg7ULwV/Chat?node-id=0%3A1.

## Демо сайта

Сайт задеплоен на netlify - https://thirsty-ride-626deb.netlify.app/

## Описание

Мессенджер на нативном JavaScript.

## Запуск

Проект разворачивается на localhost:3000

Команды:

- npm start — запуск dev версии проекта
