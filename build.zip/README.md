# Проект "Чат"

## Макет
За основу взят макет из яндекса, но с некоторыми мелкими доработками. 
https://www.figma.com/file/24EUnEHGEDNLdOcxg7ULwV/Chat?node-id=0%3A1.

## Описание

Мессенджер на TypeScript.

## Запуск

Проект разворачивается на localhost:3000

Команды:
- npm start — запуск dev версии проекта