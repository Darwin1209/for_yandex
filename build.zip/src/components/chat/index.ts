import Chat from './Chat.js'

export default Chat
