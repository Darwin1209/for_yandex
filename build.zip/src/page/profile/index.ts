import Profile from './Profile.js'

export default Profile
