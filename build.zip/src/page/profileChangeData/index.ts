import ProfileChangeData from './Profile.js'

export default ProfileChangeData
