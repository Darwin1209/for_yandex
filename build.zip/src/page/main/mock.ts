export const listText: object[] = [
	{
		name: 'Сергей',
		message: 'Изображение',
		data: '10:32',
		count: 1,
	},
	{
		name: 'Илья',
		message: 'Друзья, выпуск новостей!',
		data: '10:32',
		count: 1,
	},
	{
		name: 'Игорян',
		message: 'И Human Design рекомендуют',
		data: '10:32',
		count: 1,
	},
	{
		name: 'Игорян',
		message: 'Какой-то текст?',
		data: '10:32',
		count: 1,
	},
	{
		name: 'Игорян',
		message: 'Какой-то текст?',
		data: '10:32',
		count: 1,
	},
	{
		name: 'Игорян',
		message: 'Какой-то текст?',
		data: '10:32',
		count: 1,
	},
	{
		name: 'Игорян',
		message: 'Какой-то текст?',
		data: '10:32',
		count: 1,
	},
	{
		name: 'Игорян',
		message: 'Какой-то текст?',
		data: '10:32',
		count: 1,
	},
]
