import Main from './Main.js'

export default Main
