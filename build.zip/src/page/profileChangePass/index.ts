import ProfileChangePass from './Profile.js'

export default ProfileChangePass
