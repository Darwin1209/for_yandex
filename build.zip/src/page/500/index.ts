import E500 from './500.js'

export default E500
